import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, Sort, SortDirection } from '@angular/material/sort';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { merge, Observable, of as observableOf } from 'rxjs';
import { first } from 'rxjs/operators';

import { UserService } from '../services';
import { User } from '../models';

function compare(a: number | string | undefined, b: number | string | undefined, isAsc: boolean) {
  return (a! < b! ? -1 : 1) * (isAsc ? 1 : -1);
}

@Component({ templateUrl: 'list.html' })
export class ListComponent implements OnInit {
  users?: User[];

  displayedColumns: string[] = ['id', 'username', 'firstName', 'lastName', 'role', 'Edit', 'Delete'];

  dataSource = new MatTableDataSource(this.users!);

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private accountService: UserService) { }

  resultsLength = 0;

  ngOnInit(): void {

    this.accountService.getAll()
      .pipe(first())
      .subscribe((users) => { this.users = users; this.dataSource = new MatTableDataSource(this.users); this.dataSource.paginator = this.paginator; });
  }

  deleteUser(id: number) {

    const user = this.users!.find(x => x.id === id);

    this.accountService.delete(id)
      .pipe(first())
      .subscribe(() => { this.users = this.users!.filter(x => x.id !== id); this.dataSource = new MatTableDataSource(this.users); this.dataSource.paginator = this.paginator; });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  sortData(sort: Sort) {
    const data = this.users?.slice();
   
    this.users = data!.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'id':
          return compare(a.id, b.id, isAsc);
        case 'username':
          return compare(a.username, b.username, isAsc);
        case 'firstName':
          return compare(a.firstName, b.firstName, isAsc);
        case 'lastName':
          return compare(a.lastName, b.lastName, isAsc);
        case 'role':
          return compare(a.role, b.role, isAsc);
        default:
          return 0;
      }
    });
    this.dataSource = new MatTableDataSource(this.users);
    this.dataSource.paginator = this.paginator;
  }

}
