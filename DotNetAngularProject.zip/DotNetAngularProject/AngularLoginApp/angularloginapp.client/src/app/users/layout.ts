import { Component } from '@angular/core';

@Component({ templateUrl: 'layout.html' })
export class LayoutComponent { }
