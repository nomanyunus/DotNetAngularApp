import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { UserService } from '../services';

@Component({ templateUrl: 'layout.html' })
export class LayoutComponent {
  constructor(
    private router: Router,
    private accountService: UserService
  ) {

    if (this.accountService.userValue) {
      this.router.navigate(['/']);
    }
  }
}
