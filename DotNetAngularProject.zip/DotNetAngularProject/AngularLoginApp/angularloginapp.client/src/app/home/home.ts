import { Component } from '@angular/core';

import { User } from '../models';
import { UserService } from '../services';

@Component({ templateUrl: 'home.html' })
export class HomeComponent {
  user: User | null;

  constructor(private accountService: UserService) {
    this.user = this.accountService.userValue;
  }

  isAdmin() {
    if (this.user) {
      if (this.user.role == "Administrator")
        return true;
      else
        return false;
    }

    return false;
  }
}
