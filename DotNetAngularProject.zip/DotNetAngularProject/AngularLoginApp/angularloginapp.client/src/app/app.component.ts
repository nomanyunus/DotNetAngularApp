import { Component } from '@angular/core';

import { UserService } from './services';
import { User } from  './models';

@Component({ selector: 'app-root', templateUrl: 'app.component.html' })
export class AppComponent {
  user?: User | null;

  constructor(private accountService: UserService) {
    this.accountService.user.subscribe(x => this.user = x);
  }

 
}
