import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { User } from '../models'

@Injectable({ providedIn: 'root' })
export class UserService {
  private userSubject: BehaviorSubject<User | null>;
  public user: Observable<User | null>;

  constructor(
    private router: Router,
    private http: HttpClient
  ) {
    this.userSubject = new BehaviorSubject(JSON.parse(sessionStorage.getItem('user')!));
    this.user = this.userSubject.asObservable();
  }

  public get userValue() {
    return this.userSubject.value;
  }

  login(username: string, password: string) {
    return this.http.post<User>(`https://localhost:7291/api/authentication/authenticateuser`, { username, password })
      .pipe(map(user => {
         sessionStorage.setItem('user', JSON.stringify(user));
        this.userSubject.next(user);
        return user;
      }));
  }

  getAll() {
    return this.http.get<User[]>(`https://localhost:7291/api/authentication`);
  }

  register(user: User) {
    user.changedBy = this.userSubject.value?.username;
    return this.http.post(`https://localhost:7291/api/authentication/adduser`, user);
  }

  getById(id: string) {
    return this.http.get<User>(`https://localhost:7291/api/authentication/${id}`);
  }

  update(id: string, params: any) {
    params.changedBy = this.userSubject.value?.username;
    return this.http.put(`https://localhost:7291/api/authentication/${id}`, params);
  }

  delete(id: number) {
    return this.http.delete(`https://localhost:7291/api/authentication/${id}/${this.userSubject.value?.username}`);
  }
}
