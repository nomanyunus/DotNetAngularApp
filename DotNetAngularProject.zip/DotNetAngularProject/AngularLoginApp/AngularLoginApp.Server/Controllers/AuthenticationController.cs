﻿using AngularLoginApp.Server.Models;
using AngularLoginApp.Server.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Text.Json;
using System.Data;

namespace AngularLoginApp.Server.Controllers
{
    [AngularLoginApp.Server.Authorization.Authorize(Roles = "Administrator")] 
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly IUserService _service;
        private readonly ILogger<AuthenticationController> _logger;


        public AuthenticationController(IUserService service, ILogger<AuthenticationController> logger)
        {
            _service = service;
            _logger = logger;
        }

        [AngularLoginApp.Server.Authorization.AllowAnonymous]
        [HttpPost("authenticateuser")]
        public ActionResult<User> AuthenticateUser(AuthenticateRequest authenticateRequest)
        {
            try
            {
               
                AuthenticateResponse user = _service.Authenticate(authenticateRequest);

                if (user == null)
                {
                    _logger.LogInformation("User doesn't exist. User:{0}", authenticateRequest.Username);

                    return NotFound();
                }

                _logger.LogInformation("User authenticated. User:{0}", user.Username);

                return Ok(user);
            }
            catch(AuthenticationException ae)
            {
                return NotFound(ae.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);

                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                var users = _service.GetAll();

                return Ok(users);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);

                return BadRequest(ex.Message);
            }
        }

        [HttpPost("adduser")]
        public IActionResult adduser(AddRequest model)
        {
            try
            {
                _service.Register(model, model.changedBy);

                _logger.LogInformation("User added successfully. UserName:{0}, FirstName:{1}, LastName{2}", model.username, model.firstName, model.lastName);

                return Ok(new { message = "User added successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateRequest model)
        {
            try
            {
                _service.Update(id, model.changedBy, model);

                _logger.LogInformation("User updated successfully. UserName:{0}, FirstName:{1}, LastName{2}", model.Username, model.FirstName, model.LastName);

                return Ok(new { message = "User updated successfully" });
            }
            catch (KeyNotFoundException ke)
            {
                _logger.LogError(ke.Message, ke);

                return NotFound(ke.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);

                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}/{usr}")]
        public IActionResult Delete(int id,string usr)
        {
            try
            {
                _service.Delete(id, usr);

                _logger.LogInformation("User deleted successfully. ID:{0}",id);

                return Ok(new { message = "User deleted successfully" });
            }
            catch (KeyNotFoundException ke)
            {
                _logger.LogError(ke.Message, ke);

                return NotFound(ke.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);

                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            try
            {
                var user = _service.GetById(id);

                return Ok(user);
            }
            catch (KeyNotFoundException ke)
            {
                _logger.LogError(ke.Message, ke);

                return NotFound(ke.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);

                return BadRequest(ex.Message);
            }
        }
    }
}
