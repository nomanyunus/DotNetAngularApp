﻿namespace AngularLoginApp.Server.Models
{    public class UpdateRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string role { get; set; }
        public string changedBy { get; set; }
    }
}
