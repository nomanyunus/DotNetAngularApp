﻿using System.ComponentModel.DataAnnotations;

namespace AngularLoginApp.Server.Models
{
    public class AddRequest
    {
        [Required]
        public string firstName { get; set; }

        [Required]
        public string lastName { get; set; }

        [Required]
        public string username { get; set; }

        [Required]
        public string password { get; set; }

        public string role { get; set; }

        public string changedBy { get; set; }

    }
}
