﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace AngularLoginApp.Server.Models
{
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; private set; }
        public string username { get;  set; }
        public string password { get;  set; }
        public string firstName { get;  set; }
        public string lastName { get;  set; }
        public string role { get;  set; }
        
    }
}
