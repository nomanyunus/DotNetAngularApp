﻿using AngularLoginApp.Server.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Reflection;

namespace AngularLoginApp.Server
{
    public class AppDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<AuditEntry> AuditEntry { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
    }
}
