﻿using AngularLoginApp.Server.Models;
using Microsoft.EntityFrameworkCore;
using NLog.LayoutRenderers.Wrappers;

namespace AngularLoginApp.Server.Service
{
    public interface IAuditTrailService<T>
    {
        void Update(T entity, string createdBy);
        void Delete(T entity, string createdBy);
        void Insert(T entity, string createdBy);

    }

    public class AuditTrailService<T> : IAuditTrailService<T> where T : class
    {
        private AppDbContext _context;
        private readonly ILogger<AuditTrailService<T>> _logger;

        public AuditTrailService(
           AppDbContext context, ILogger<AuditTrailService<T>> logger)
        {
            _context = context;
            _logger = logger;
        }

        public void Delete(T entity, string createdBy)
        {
            try
            {
                User user = (User)Convert.ChangeType(entity, typeof(User));

                _logger.LogInformation("Adding audit trail entry. Delete User:{0}", user.username);

                AuditEntry entry = new AuditEntry();

                entry.UserName = user.username;
                entry.FirstName = user.firstName;
                entry.LastName = user.lastName;
                entry.CreatedBy = createdBy;
                entry.CreatedDate = DateTime.Now.Date;
                entry.AppplicationName = "AngularLoginApp";
                entry.State = StateName.Deleted.ToString();

                _context.AuditEntry.Add(entry);
                _context.SaveChanges();

                _logger.LogInformation("Audit trail entry added. Delete User:{0}", user.username);
            }
            catch (Exception) { throw; }
        }

     
        public void Insert(T entity, string createdBy)
        {
            try
            {
                User user = (User)Convert.ChangeType(entity, typeof(User));

                _logger.LogInformation("Adding audit trail entry. Isert User:{0}", user.username);

                AuditEntry entry = new AuditEntry();

                entry.UserName = user.username;
                entry.FirstName = user.firstName;
                entry.LastName = user.lastName;
                entry.CreatedBy = createdBy;
                entry.CreatedDate = DateTime.Now.Date;
                entry.AppplicationName = "AngularLoginApp";
                entry.State = StateName.Added.ToString();

                _context.AuditEntry.Add(entry);
                _context.SaveChanges();

                _logger.LogInformation("Audit trail entry added. Insert User:{0}", user.username);

            }
            catch (Exception) { throw; }
        }

        public void Update(T entity, string createdBy)
        {
            try
            {
                User user = (User)Convert.ChangeType(entity, typeof(User));

                _logger.LogInformation("Adding audit trail entry. Update User:{0}", user.username);

                AuditEntry entry = new AuditEntry();

                entry.UserName = user.username;
                entry.FirstName = user.firstName;
                entry.LastName = user.lastName;
                entry.CreatedBy = createdBy;
                entry.CreatedDate = DateTime.Now.Date;
                entry.AppplicationName = "AngularLoginApp";
                entry.State = StateName.Modified.ToString();

                _context.AuditEntry.Add(entry);
                _context.SaveChanges();

                _logger.LogInformation("Audit trail entry added. Update User:{0}", user.username);
            }
            catch (Exception) { throw; }
        }
    }
}
