﻿using AngularLoginApp.Server.Authorization;
using AngularLoginApp.Server.Controllers;
using AngularLoginApp.Server.Models;
using AutoMapper;
using Microsoft.AspNetCore.Identity.Data;

namespace AngularLoginApp.Server.Service
{
    public interface IUserService
    {
        IEnumerable<User> GetAll();
        User GetById(int id);
        AuthenticateResponse Authenticate(AuthenticateRequest model);
        void Update(int id, string changedBy, UpdateRequest model);
        void Delete(int id, string changedBy);
        void Register(AddRequest model, string changedBy);

    }

    public class UserService : IUserService
    {
        private AppDbContext _context;
        private IAuditTrailService<User> _auditTrailService;
        private readonly ILogger<UserService> _logger;
        private IJwtUtils _jwtUtils;
        private readonly IMapper _mapper;

        public UserService(
            AppDbContext context, IAuditTrailService<User> auditTrailService, ILogger<UserService> logger, IJwtUtils jwtUtils,
        IMapper mapper)
        {
            _context = context;
            _auditTrailService = auditTrailService;
            _logger = logger;
            _mapper = mapper;
            _jwtUtils = jwtUtils;
        }

     
        public AuthenticateResponse Authenticate(AuthenticateRequest model)
        {

            User usr = _context.Users.Where(x => x.username == model.Username).FirstOrDefault();

            if (usr == null || Cryptograph.Decrypt(usr.password, "mysecretkey") != model.Password)
            {
                _logger.LogInformation("User password doesn't macth. User:{0}", model.Username);

                throw new AuthenticationException("Username or password is incorrect");
            }

            var response = _mapper.Map<AuthenticateResponse>(usr);
            response.Token = _jwtUtils.GenerateToken(usr);
            return response;

        }

        public IEnumerable<User> GetAll()
        {
            try
            {
                return _context.Users;
            }
            catch(Exception)
            {
                throw;
            }
        }

        public User GetById(int id)
        {
            return getUser(id);
        }


        public void Register(AddRequest model, string changedBy)
        {
            try
            {
                User user = new User();
                user.username = model.username;
                user.password = Cryptograph.Encrypt(model.password, "mysecretkey");
                user.firstName = model.firstName;
                user.lastName = model.lastName;
                user.role = model.role;

                _context.Users.Add(user);
                _context.SaveChanges();

                _logger.LogInformation("User added. User:{0}", model.username);

                _auditTrailService.Insert(user, changedBy);
            }
            catch(Exception)
            {
                throw;
            }
        }

        public void Update(int id,string changedBy, UpdateRequest model)
        {
            try
            {
                var user = getUser(id);

                user.username = model.Username;
                user.password = Cryptograph.Encrypt(model.Password, "mysecretkey");
                user.firstName = model.FirstName;
                user.lastName = model.LastName;
                user.role = model.role;
                _context.Users.Update(user);
                _context.SaveChanges();

                _logger.LogInformation("User updated. User:{0}", model.Username);

                _auditTrailService.Update(user, changedBy);
            }
            catch (KeyNotFoundException)
            {
                throw;
            }
            catch (Exception) {
                throw;
            }
        }

        public void Delete(int id, string changedBy)
        {
            try
            {
                var user = getUser(id);
                _context.Users.Remove(user);
                _context.SaveChanges();

                _logger.LogInformation("User deleted. User:{0}", id);

                _auditTrailService.Delete(user, changedBy);
            }
            catch (KeyNotFoundException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

        }

       
        private User getUser(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null) throw new KeyNotFoundException("User not found");
            return user;
        }
    }
}
